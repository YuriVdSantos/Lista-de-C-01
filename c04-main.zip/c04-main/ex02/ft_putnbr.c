#include <unistd.h>
#include <limits.h>

void	ft_putnbr(int nb)
{
	char	j;

	if (nb == -2147483648)
		write (1, "-2147483648", 11);
	if (nb < 0)
	{
		write(1, "-", 1);
		nb *= -1;
	}
	if (nb > 9)
		ft_putnbr(nb / 10);
	j = nb % 10 + '0';
	write(1, &j, 1);
}

int main (void)
{
	ft_putnbr(-123784);
}