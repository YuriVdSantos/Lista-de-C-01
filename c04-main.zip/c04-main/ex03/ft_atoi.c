
int	ft_atoi(char *str)
{
	int	i;
	int	sign;
	int	number;

	i = 0;
	sign = 1;
	number = 0;
	while (str[i]!= '\0')
	{
		if (str[i] == 32 || (str[i] >= 9 && str[i] <= 13))
			i++;
		else if (str[i] == '+')
			i++;
		else if (str[i] == '-')
		{
			sign *= -1;
			i++;
		}
		else if (str[i] >= 48 && str[i] <= 57)
		{
			number = number * 10 + (str[i] - '0');
			i++;
		}
		else if ((str[i] >= 65 && str[i] <= 90)
					||(str[i] >= 97 && str[i] <= 122))
		{
			break;
		}
	}
	return (sign * number);
}

// #include <stdio.h>
// int main(void)
// {
//     printf("%d",ft_atoi("---+--+1234ab567"));
// }